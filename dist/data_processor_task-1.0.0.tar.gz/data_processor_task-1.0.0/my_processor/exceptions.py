class InvalidMemberDataError(Exception):
    "Raised when member data is invalid"
    pass