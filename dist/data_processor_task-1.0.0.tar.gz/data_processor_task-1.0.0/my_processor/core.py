"""
Core module containing the Member class.
"""

from my_processor.utils import (
    clean_name,
    validate_name,
    validate_email,
    validate_phone,
)

from my_processor.exceptions import InvalidMemberDataError


class Member:
    """
    Represents a single member.
    """

    def __init__(self, name, email, phone):
        """
        Initialize a Member object after validating the data.
        """

        self.name = clean_name(name)

        if not validate_name(self.name):
            raise InvalidMemberDataError(
                f"Invalid name: {self.name}"
            )

        if not validate_email(email):
            raise InvalidMemberDataError(
                f"Invalid email: {email}"
            )

        if not validate_phone(phone):
            raise InvalidMemberDataError(
                f"Invalid phone number: {phone}"
            )

        self.email = email
        self.phone = phone

    def __str__(self):
        """
        String representation of the object.
        """
        return (
            f"Member(Name={self.name}, "
            f"Email={self.email}, "
            f"Phone={self.phone})"
        )