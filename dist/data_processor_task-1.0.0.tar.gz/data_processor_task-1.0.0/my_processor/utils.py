"""
Utility functions for cleaning and validating member data.
"""

import re


def clean_name(name):
    """
    Remove leading and trailing spaces from the name.
    """
    return name.strip()


def validate_name(name):
    """
    Name should contain only alphabets and spaces.
    """
    pattern = r"^[A-Za-z]+(?: [A-Za-z]+)*$"
    return bool(re.fullmatch(pattern, name))


def validate_email(email):
    """
    Validate email format.
    """
    pattern = r"^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}$"
    return bool(re.fullmatch(pattern, email))


def validate_phone(phone):
    """
    Validate a 10-digit mobile number.
    """
    pattern = r"^[0-9]{10}$"
    return bool(re.fullmatch(pattern, phone))